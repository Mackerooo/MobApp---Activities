package com.example.settingsactivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private JSONSerializer mSerializer;
    private List<Note> mNotes;
    private RecyclerView mRecyclerView;
    private NoteAdapter mAdapter;
    private SharedPreferences mPrefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setSupportActionBar(findViewById(R.id.toolbar));

        mSerializer = new JSONSerializer("NoteToSelf.json", getApplicationContext());
        try {
            mNotes = mSerializer.load();
        } catch (Exception e) {
            mNotes = new ArrayList<>();
        }

        mPrefs = getSharedPreferences("NoteToSelf", MODE_PRIVATE);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(view -> {
            DialogNewNote dialog = new DialogNewNote();
            dialog.show(getSupportFragmentManager(), "");
        });

        mRecyclerView = findViewById(R.id.recyclerView);
        mAdapter = new NoteAdapter(this, mNotes);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setAdapter(mAdapter);
    }

    // Update the adapter's divider setting based on SharedPreferences
    private void updateDividerSetting() {
        boolean showDividers = mPrefs.getBoolean("dividers", true);
        mAdapter.setShowDividers(showDividers);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_settings) {
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateDividerSetting();
        mAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            mSerializer.save(mNotes);
        } catch (Exception e) {
            // Handle error
        }
    }

    public void createNewNote(Note note) {
        mNotes.add(note);
        mAdapter.notifyItemInserted(mNotes.size() - 1);
    }


}
