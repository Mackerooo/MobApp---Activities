package com.example.settingsactivity;

import android.os.Bundle;
import android.widget.Switch;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {
    private android.content.SharedPreferences.Editor mEditor;
    private boolean mShowDividers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Use the consistent SharedPreferences name "NoteToSelf"
        android.content.SharedPreferences mPrefs = getSharedPreferences("NoteToSelf", MODE_PRIVATE);
        mEditor = mPrefs.edit();
        mShowDividers = mPrefs.getBoolean("dividers", true);

        Switch switch1 = findViewById(R.id.switch1);
        switch1.setChecked(mShowDividers);

        switch1.setOnCheckedChangeListener((buttonView, isChecked) -> {
            mEditor.putBoolean("dividers", isChecked);
            mShowDividers = isChecked;
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        mEditor.commit(); // Save when leaving the activity
    }
}
