package com.example.settingsactivity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

public class DialogShowNote extends DialogFragment {
    private Note mNote;

    public void sendNoteSelected(Note noteToShow) {
        mNote = noteToShow;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_show_note, null);

        TextView txtTitle = dialogView.findViewById(R.id.txtTitle);
        TextView txtDescription = dialogView.findViewById(R.id.txtDescription);
        CheckBox chkIdea = dialogView.findViewById(R.id.chkIdea);
        CheckBox chkTodo = dialogView.findViewById(R.id.chkTodo);
        CheckBox chkImportant = dialogView.findViewById(R.id.chkImportant);

        txtTitle.setText(mNote.getTitle());
        txtDescription.setText(mNote.getDescription());
        chkIdea.setChecked(mNote.isIdea());
        chkTodo.setChecked(mNote.isTodo());
        chkImportant.setChecked(mNote.isImportant());

        // Disable checkboxes for viewing only
        chkIdea.setEnabled(false);
        chkTodo.setEnabled(false);
        chkImportant.setEnabled(false);

        builder.setView(dialogView)
                .setTitle(getString(R.string.your_note))
                .setNegativeButton(getString(R.string.cancel_button), (dialog, which) -> {
                    // Just close the dialog
                });

        return builder.create();
    }
}