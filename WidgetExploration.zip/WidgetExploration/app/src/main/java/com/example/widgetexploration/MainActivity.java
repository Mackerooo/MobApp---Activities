package com.example.widgetexploration;

import android.graphics.Color;
import android.graphics.PorterDuff;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AnalogClock;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextClock;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Initializing UI components
        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        final EditText editText = findViewById(R.id.editText);
        final Button button = findViewById(R.id.button);
        final TextClock textClock = findViewById(R.id.textClock);
        final CheckBox cbTransparency = findViewById(R.id.checkBoxTransparency);
        final CheckBox cbTint = findViewById(R.id.checkBoxTint);
        final CheckBox cbReSize = findViewById(R.id.checkBoxReSize);
        final ImageView imageView = findViewById(R.id.imageView);
        final Switch switch1 = findViewById(R.id.switch1);
        final TextView textView = findViewById(R.id.textView);

        // Transparency Checkbox Listener
        cbTransparency.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                imageView.setAlpha(isChecked ? 0.1f : 1f);
            }
        });

        // Tint Checkbox Listener
        cbTint.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // Apply red tint
                    imageView.setColorFilter(Color.argb(150, 255, 0, 0));
                } else {
                    // Remove tint
                    imageView.clearColorFilter();
                }
            }
        });

        // Resize Checkbox Listener
        cbReSize.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                imageView.setScaleX(isChecked ? 2 : 1);
                imageView.setScaleY(isChecked ? 2 : 1);
            }
        });

        // RadioGroup Listener for Changing TimeZone
        radioGroup.clearCheck();
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rb = group.findViewById(checkedId);
                if (rb == null) return; // Prevent NullPointerException

                if (rb.getId() == R.id.radioButtonLondon) {
                    textClock.setTimeZone("Europe/London");
                } else if (rb.getId() == R.id.radioButtonBeijing) {
                    textClock.setTimeZone("Etc/GMT-8");
                } else if (rb.getId() == R.id.radioButtonNewYork) {
                    textClock.setTimeZone("America/New_York");
                }
            }
        });


        // Button Click Listener to Update TextView and Hide Keyboard
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Set the text from EditText to TextView
                textView.setText(editText.getText().toString());

                // Hide the keyboard
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }
            }
        });
    }
}
